﻿namespace WF_Calendar
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Label_5_6 = new System.Windows.Forms.Label();
            this.Label_5_5 = new System.Windows.Forms.Label();
            this.Label_4_6 = new System.Windows.Forms.Label();
            this.Label_4_5 = new System.Windows.Forms.Label();
            this.Label_3_6 = new System.Windows.Forms.Label();
            this.Label_3_5 = new System.Windows.Forms.Label();
            this.Label_5_3 = new System.Windows.Forms.Label();
            this.Label_2_6 = new System.Windows.Forms.Label();
            this.Label_4_3 = new System.Windows.Forms.Label();
            this.Label_2_5 = new System.Windows.Forms.Label();
            this.Label_3_3 = new System.Windows.Forms.Label();
            this.Label_5_4 = new System.Windows.Forms.Label();
            this.Label_1_6 = new System.Windows.Forms.Label();
            this.Label_4_4 = new System.Windows.Forms.Label();
            this.Label_2_3 = new System.Windows.Forms.Label();
            this.Label_3_4 = new System.Windows.Forms.Label();
            this.Label_5_2 = new System.Windows.Forms.Label();
            this.Label_1_5 = new System.Windows.Forms.Label();
            this.Label_4_2 = new System.Windows.Forms.Label();
            this.Label_2_4 = new System.Windows.Forms.Label();
            this.Label_3_2 = new System.Windows.Forms.Label();
            this.Label_1_3 = new System.Windows.Forms.Label();
            this.Label_2_2 = new System.Windows.Forms.Label();
            this.Label_1_4 = new System.Windows.Forms.Label();
            this.Label_1_2 = new System.Windows.Forms.Label();
            this.Label_5_1 = new System.Windows.Forms.Label();
            this.Label_0_6 = new System.Windows.Forms.Label();
            this.Label_4_1 = new System.Windows.Forms.Label();
            this.Label_0_5 = new System.Windows.Forms.Label();
            this.Label_3_1 = new System.Windows.Forms.Label();
            this.Label_0_3 = new System.Windows.Forms.Label();
            this.Label_5_0 = new System.Windows.Forms.Label();
            this.Label_2_1 = new System.Windows.Forms.Label();
            this.Label_4_0 = new System.Windows.Forms.Label();
            this.Label_0_4 = new System.Windows.Forms.Label();
            this.Label_3_0 = new System.Windows.Forms.Label();
            this.Label_1_1 = new System.Windows.Forms.Label();
            this.Label_2_0 = new System.Windows.Forms.Label();
            this.Label_0_2 = new System.Windows.Forms.Label();
            this.Label_1_0 = new System.Windows.Forms.Label();
            this.Label_0_1 = new System.Windows.Forms.Label();
            this.Label_0_0 = new System.Windows.Forms.Label();
            this.Lab_Sunday = new System.Windows.Forms.Label();
            this.Lab_Saturday = new System.Windows.Forms.Label();
            this.Lab_Friday = new System.Windows.Forms.Label();
            this.Lab_Thursday = new System.Windows.Forms.Label();
            this.Lab_Wednesday = new System.Windows.Forms.Label();
            this.Lab_Tuesday = new System.Windows.Forms.Label();
            this.Lab_Monday = new System.Windows.Forms.Label();
            this.RTB_3_6 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_6 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_5 = new System.Windows.Forms.RichTextBox();
            this.RTB_3_5 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_5 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_3 = new System.Windows.Forms.RichTextBox();
            this.RTB_3_3 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_3 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_1 = new System.Windows.Forms.RichTextBox();
            this.RTB_3_1 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_1 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_6 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_6 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_6 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_5 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_5 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_5 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_4 = new System.Windows.Forms.RichTextBox();
            this.RTB_3_4 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_4 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_3 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_3 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_3 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_2 = new System.Windows.Forms.RichTextBox();
            this.RTB_3_2 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_2 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_4 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_4 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_4 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_1 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_1 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_1 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_2 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_2 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_2 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_0 = new System.Windows.Forms.RichTextBox();
            this.RTB_4_0 = new System.Windows.Forms.RichTextBox();
            this.RTB_3_0 = new System.Windows.Forms.RichTextBox();
            this.RTB_2_0 = new System.Windows.Forms.RichTextBox();
            this.RTB_1_0 = new System.Windows.Forms.RichTextBox();
            this.RTB_0_0 = new System.Windows.Forms.RichTextBox();
            this.RTB_5_6 = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Lab_Month_Oct = new System.Windows.Forms.Label();
            this.Lab_year_2020 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BusyHours = new System.Windows.Forms.Label();
            this.BusyDays = new System.Windows.Forms.Label();
            this.FreeHours = new System.Windows.Forms.Label();
            this.FreeDays = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button3 = new System.Windows.Forms.Button();
            this.button_selected_Date = new System.Windows.Forms.Button();
            this.Lab_Calculate = new System.Windows.Forms.Label();
            this.Calculate_work = new System.Windows.Forms.Button();
            this.Name_KA = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.addEvent = new System.Windows.Forms.Button();
            this.displayEvent = new System.Windows.Forms.TextBox();
            this.textEvent = new System.Windows.Forms.TextBox();
            this.timeEvent = new System.Windows.Forms.MaskedTextBox();
            this.dateEvent = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Thistle;
            this.groupBox1.Controls.Add(this.Label_5_6);
            this.groupBox1.Controls.Add(this.Label_5_5);
            this.groupBox1.Controls.Add(this.Label_4_6);
            this.groupBox1.Controls.Add(this.Label_4_5);
            this.groupBox1.Controls.Add(this.Label_3_6);
            this.groupBox1.Controls.Add(this.Label_3_5);
            this.groupBox1.Controls.Add(this.Label_5_3);
            this.groupBox1.Controls.Add(this.Label_2_6);
            this.groupBox1.Controls.Add(this.Label_4_3);
            this.groupBox1.Controls.Add(this.Label_2_5);
            this.groupBox1.Controls.Add(this.Label_3_3);
            this.groupBox1.Controls.Add(this.Label_5_4);
            this.groupBox1.Controls.Add(this.Label_1_6);
            this.groupBox1.Controls.Add(this.Label_4_4);
            this.groupBox1.Controls.Add(this.Label_2_3);
            this.groupBox1.Controls.Add(this.Label_3_4);
            this.groupBox1.Controls.Add(this.Label_5_2);
            this.groupBox1.Controls.Add(this.Label_1_5);
            this.groupBox1.Controls.Add(this.Label_4_2);
            this.groupBox1.Controls.Add(this.Label_2_4);
            this.groupBox1.Controls.Add(this.Label_3_2);
            this.groupBox1.Controls.Add(this.Label_1_3);
            this.groupBox1.Controls.Add(this.Label_2_2);
            this.groupBox1.Controls.Add(this.Label_1_4);
            this.groupBox1.Controls.Add(this.Label_1_2);
            this.groupBox1.Controls.Add(this.Label_5_1);
            this.groupBox1.Controls.Add(this.Label_0_6);
            this.groupBox1.Controls.Add(this.Label_4_1);
            this.groupBox1.Controls.Add(this.Label_0_5);
            this.groupBox1.Controls.Add(this.Label_3_1);
            this.groupBox1.Controls.Add(this.Label_0_3);
            this.groupBox1.Controls.Add(this.Label_5_0);
            this.groupBox1.Controls.Add(this.Label_2_1);
            this.groupBox1.Controls.Add(this.Label_4_0);
            this.groupBox1.Controls.Add(this.Label_0_4);
            this.groupBox1.Controls.Add(this.Label_3_0);
            this.groupBox1.Controls.Add(this.Label_1_1);
            this.groupBox1.Controls.Add(this.Label_2_0);
            this.groupBox1.Controls.Add(this.Label_0_2);
            this.groupBox1.Controls.Add(this.Label_1_0);
            this.groupBox1.Controls.Add(this.Label_0_1);
            this.groupBox1.Controls.Add(this.Label_0_0);
            this.groupBox1.Controls.Add(this.Lab_Sunday);
            this.groupBox1.Controls.Add(this.Lab_Saturday);
            this.groupBox1.Controls.Add(this.Lab_Friday);
            this.groupBox1.Controls.Add(this.Lab_Thursday);
            this.groupBox1.Controls.Add(this.Lab_Wednesday);
            this.groupBox1.Controls.Add(this.Lab_Tuesday);
            this.groupBox1.Controls.Add(this.Lab_Monday);
            this.groupBox1.Controls.Add(this.RTB_3_6);
            this.groupBox1.Controls.Add(this.RTB_1_6);
            this.groupBox1.Controls.Add(this.RTB_5_5);
            this.groupBox1.Controls.Add(this.RTB_3_5);
            this.groupBox1.Controls.Add(this.RTB_1_5);
            this.groupBox1.Controls.Add(this.RTB_5_3);
            this.groupBox1.Controls.Add(this.RTB_3_3);
            this.groupBox1.Controls.Add(this.RTB_1_3);
            this.groupBox1.Controls.Add(this.RTB_5_1);
            this.groupBox1.Controls.Add(this.RTB_3_1);
            this.groupBox1.Controls.Add(this.RTB_1_1);
            this.groupBox1.Controls.Add(this.RTB_4_6);
            this.groupBox1.Controls.Add(this.RTB_2_6);
            this.groupBox1.Controls.Add(this.RTB_0_6);
            this.groupBox1.Controls.Add(this.RTB_4_5);
            this.groupBox1.Controls.Add(this.RTB_2_5);
            this.groupBox1.Controls.Add(this.RTB_0_5);
            this.groupBox1.Controls.Add(this.RTB_5_4);
            this.groupBox1.Controls.Add(this.RTB_3_4);
            this.groupBox1.Controls.Add(this.RTB_1_4);
            this.groupBox1.Controls.Add(this.RTB_4_3);
            this.groupBox1.Controls.Add(this.RTB_2_3);
            this.groupBox1.Controls.Add(this.RTB_0_3);
            this.groupBox1.Controls.Add(this.RTB_5_2);
            this.groupBox1.Controls.Add(this.RTB_3_2);
            this.groupBox1.Controls.Add(this.RTB_1_2);
            this.groupBox1.Controls.Add(this.RTB_4_4);
            this.groupBox1.Controls.Add(this.RTB_2_4);
            this.groupBox1.Controls.Add(this.RTB_0_4);
            this.groupBox1.Controls.Add(this.RTB_4_1);
            this.groupBox1.Controls.Add(this.RTB_2_1);
            this.groupBox1.Controls.Add(this.RTB_0_1);
            this.groupBox1.Controls.Add(this.RTB_4_2);
            this.groupBox1.Controls.Add(this.RTB_2_2);
            this.groupBox1.Controls.Add(this.RTB_0_2);
            this.groupBox1.Controls.Add(this.RTB_5_0);
            this.groupBox1.Controls.Add(this.RTB_4_0);
            this.groupBox1.Controls.Add(this.RTB_3_0);
            this.groupBox1.Controls.Add(this.RTB_2_0);
            this.groupBox1.Controls.Add(this.RTB_1_0);
            this.groupBox1.Controls.Add(this.RTB_0_0);
            this.groupBox1.Controls.Add(this.RTB_5_6);
            this.groupBox1.Location = new System.Drawing.Point(206, 105);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(591, 514);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // Label_5_6
            // 
            this.Label_5_6.AutoSize = true;
            this.Label_5_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_5_6.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_6.Location = new System.Drawing.Point(494, 405);
            this.Label_5_6.Name = "Label_5_6";
            this.Label_5_6.Size = new System.Drawing.Size(23, 25);
            this.Label_5_6.TabIndex = 2;
            this.Label_5_6.Text = "0";
            this.Label_5_6.Click += new System.EventHandler(this.label21_Click);
            // 
            // Label_5_5
            // 
            this.Label_5_5.AutoSize = true;
            this.Label_5_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_5_5.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_5.Location = new System.Drawing.Point(414, 405);
            this.Label_5_5.Name = "Label_5_5";
            this.Label_5_5.Size = new System.Drawing.Size(23, 25);
            this.Label_5_5.TabIndex = 2;
            this.Label_5_5.Text = "0";
            this.Label_5_5.Click += new System.EventHandler(this.label19_Click);
            // 
            // Label_4_6
            // 
            this.Label_4_6.AutoSize = true;
            this.Label_4_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_4_6.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_6.Location = new System.Drawing.Point(494, 333);
            this.Label_4_6.Name = "Label_4_6";
            this.Label_4_6.Size = new System.Drawing.Size(23, 25);
            this.Label_4_6.TabIndex = 2;
            this.Label_4_6.Text = "0";
            this.Label_4_6.Click += new System.EventHandler(this.label21_Click);
            // 
            // Label_4_5
            // 
            this.Label_4_5.AutoSize = true;
            this.Label_4_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_4_5.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_5.Location = new System.Drawing.Point(414, 333);
            this.Label_4_5.Name = "Label_4_5";
            this.Label_4_5.Size = new System.Drawing.Size(34, 25);
            this.Label_4_5.TabIndex = 2;
            this.Label_4_5.Text = "31";
            this.Label_4_5.Click += new System.EventHandler(this.label19_Click);
            // 
            // Label_3_6
            // 
            this.Label_3_6.AutoSize = true;
            this.Label_3_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_3_6.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_6.Location = new System.Drawing.Point(494, 262);
            this.Label_3_6.Name = "Label_3_6";
            this.Label_3_6.Size = new System.Drawing.Size(34, 25);
            this.Label_3_6.TabIndex = 2;
            this.Label_3_6.Text = "25";
            this.Label_3_6.Click += new System.EventHandler(this.label21_Click);
            // 
            // Label_3_5
            // 
            this.Label_3_5.AutoSize = true;
            this.Label_3_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_3_5.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_5.Location = new System.Drawing.Point(414, 262);
            this.Label_3_5.Name = "Label_3_5";
            this.Label_3_5.Size = new System.Drawing.Size(34, 25);
            this.Label_3_5.TabIndex = 2;
            this.Label_3_5.Text = "24";
            this.Label_3_5.Click += new System.EventHandler(this.label19_Click);
            // 
            // Label_5_3
            // 
            this.Label_5_3.AutoSize = true;
            this.Label_5_3.BackColor = System.Drawing.Color.White;
            this.Label_5_3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_3.Location = new System.Drawing.Point(258, 405);
            this.Label_5_3.Name = "Label_5_3";
            this.Label_5_3.Size = new System.Drawing.Size(23, 25);
            this.Label_5_3.TabIndex = 2;
            this.Label_5_3.Text = "0";
            // 
            // Label_2_6
            // 
            this.Label_2_6.AutoSize = true;
            this.Label_2_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_2_6.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_6.Location = new System.Drawing.Point(494, 192);
            this.Label_2_6.Name = "Label_2_6";
            this.Label_2_6.Size = new System.Drawing.Size(34, 25);
            this.Label_2_6.TabIndex = 2;
            this.Label_2_6.Text = "18";
            // 
            // Label_4_3
            // 
            this.Label_4_3.AutoSize = true;
            this.Label_4_3.BackColor = System.Drawing.Color.White;
            this.Label_4_3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_3.Location = new System.Drawing.Point(258, 333);
            this.Label_4_3.Name = "Label_4_3";
            this.Label_4_3.Size = new System.Drawing.Size(34, 25);
            this.Label_4_3.TabIndex = 2;
            this.Label_4_3.Text = "29";
            // 
            // Label_2_5
            // 
            this.Label_2_5.AutoSize = true;
            this.Label_2_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_2_5.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_5.Location = new System.Drawing.Point(414, 192);
            this.Label_2_5.Name = "Label_2_5";
            this.Label_2_5.Size = new System.Drawing.Size(34, 25);
            this.Label_2_5.TabIndex = 2;
            this.Label_2_5.Text = "17";
            // 
            // Label_3_3
            // 
            this.Label_3_3.AutoSize = true;
            this.Label_3_3.BackColor = System.Drawing.Color.White;
            this.Label_3_3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_3.Location = new System.Drawing.Point(258, 262);
            this.Label_3_3.Name = "Label_3_3";
            this.Label_3_3.Size = new System.Drawing.Size(34, 25);
            this.Label_3_3.TabIndex = 2;
            this.Label_3_3.Text = "22";
            // 
            // Label_5_4
            // 
            this.Label_5_4.AutoSize = true;
            this.Label_5_4.BackColor = System.Drawing.Color.White;
            this.Label_5_4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_4.Location = new System.Drawing.Point(336, 405);
            this.Label_5_4.Name = "Label_5_4";
            this.Label_5_4.Size = new System.Drawing.Size(23, 25);
            this.Label_5_4.TabIndex = 2;
            this.Label_5_4.Text = "0";
            // 
            // Label_1_6
            // 
            this.Label_1_6.AutoSize = true;
            this.Label_1_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_1_6.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_6.Location = new System.Drawing.Point(494, 121);
            this.Label_1_6.Name = "Label_1_6";
            this.Label_1_6.Size = new System.Drawing.Size(34, 25);
            this.Label_1_6.TabIndex = 2;
            this.Label_1_6.Text = "11";
            // 
            // Label_4_4
            // 
            this.Label_4_4.AutoSize = true;
            this.Label_4_4.BackColor = System.Drawing.Color.White;
            this.Label_4_4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_4.Location = new System.Drawing.Point(336, 333);
            this.Label_4_4.Name = "Label_4_4";
            this.Label_4_4.Size = new System.Drawing.Size(34, 25);
            this.Label_4_4.TabIndex = 2;
            this.Label_4_4.Text = "30";
            // 
            // Label_2_3
            // 
            this.Label_2_3.AutoSize = true;
            this.Label_2_3.BackColor = System.Drawing.Color.White;
            this.Label_2_3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_3.Location = new System.Drawing.Point(258, 192);
            this.Label_2_3.Name = "Label_2_3";
            this.Label_2_3.Size = new System.Drawing.Size(34, 25);
            this.Label_2_3.TabIndex = 2;
            this.Label_2_3.Text = "15";
            // 
            // Label_3_4
            // 
            this.Label_3_4.AutoSize = true;
            this.Label_3_4.BackColor = System.Drawing.Color.White;
            this.Label_3_4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_4.Location = new System.Drawing.Point(336, 262);
            this.Label_3_4.Name = "Label_3_4";
            this.Label_3_4.Size = new System.Drawing.Size(34, 25);
            this.Label_3_4.TabIndex = 2;
            this.Label_3_4.Text = "23";
            // 
            // Label_5_2
            // 
            this.Label_5_2.AutoSize = true;
            this.Label_5_2.BackColor = System.Drawing.Color.White;
            this.Label_5_2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_2.Location = new System.Drawing.Point(180, 405);
            this.Label_5_2.Name = "Label_5_2";
            this.Label_5_2.Size = new System.Drawing.Size(23, 25);
            this.Label_5_2.TabIndex = 2;
            this.Label_5_2.Text = "0";
            // 
            // Label_1_5
            // 
            this.Label_1_5.AutoSize = true;
            this.Label_1_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_1_5.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_5.Location = new System.Drawing.Point(414, 121);
            this.Label_1_5.Name = "Label_1_5";
            this.Label_1_5.Size = new System.Drawing.Size(34, 25);
            this.Label_1_5.TabIndex = 2;
            this.Label_1_5.Text = "10";
            // 
            // Label_4_2
            // 
            this.Label_4_2.AutoSize = true;
            this.Label_4_2.BackColor = System.Drawing.Color.White;
            this.Label_4_2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_2.Location = new System.Drawing.Point(180, 333);
            this.Label_4_2.Name = "Label_4_2";
            this.Label_4_2.Size = new System.Drawing.Size(34, 25);
            this.Label_4_2.TabIndex = 2;
            this.Label_4_2.Text = "28";
            // 
            // Label_2_4
            // 
            this.Label_2_4.AutoSize = true;
            this.Label_2_4.BackColor = System.Drawing.Color.White;
            this.Label_2_4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_4.Location = new System.Drawing.Point(336, 192);
            this.Label_2_4.Name = "Label_2_4";
            this.Label_2_4.Size = new System.Drawing.Size(34, 25);
            this.Label_2_4.TabIndex = 2;
            this.Label_2_4.Text = "16";
            // 
            // Label_3_2
            // 
            this.Label_3_2.AutoSize = true;
            this.Label_3_2.BackColor = System.Drawing.Color.White;
            this.Label_3_2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_2.Location = new System.Drawing.Point(180, 262);
            this.Label_3_2.Name = "Label_3_2";
            this.Label_3_2.Size = new System.Drawing.Size(34, 25);
            this.Label_3_2.TabIndex = 2;
            this.Label_3_2.Text = "21";
            // 
            // Label_1_3
            // 
            this.Label_1_3.AutoSize = true;
            this.Label_1_3.BackColor = System.Drawing.Color.White;
            this.Label_1_3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_3.Location = new System.Drawing.Point(258, 121);
            this.Label_1_3.Name = "Label_1_3";
            this.Label_1_3.Size = new System.Drawing.Size(23, 25);
            this.Label_1_3.TabIndex = 2;
            this.Label_1_3.Text = "8";
            // 
            // Label_2_2
            // 
            this.Label_2_2.AutoSize = true;
            this.Label_2_2.BackColor = System.Drawing.Color.White;
            this.Label_2_2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_2.Location = new System.Drawing.Point(180, 192);
            this.Label_2_2.Name = "Label_2_2";
            this.Label_2_2.Size = new System.Drawing.Size(34, 25);
            this.Label_2_2.TabIndex = 2;
            this.Label_2_2.Text = "14";
            // 
            // Label_1_4
            // 
            this.Label_1_4.AutoSize = true;
            this.Label_1_4.BackColor = System.Drawing.Color.White;
            this.Label_1_4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_4.Location = new System.Drawing.Point(336, 121);
            this.Label_1_4.Name = "Label_1_4";
            this.Label_1_4.Size = new System.Drawing.Size(23, 25);
            this.Label_1_4.TabIndex = 2;
            this.Label_1_4.Text = "9";
            // 
            // Label_1_2
            // 
            this.Label_1_2.AutoSize = true;
            this.Label_1_2.BackColor = System.Drawing.Color.White;
            this.Label_1_2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_2.Location = new System.Drawing.Point(180, 121);
            this.Label_1_2.Name = "Label_1_2";
            this.Label_1_2.Size = new System.Drawing.Size(23, 25);
            this.Label_1_2.TabIndex = 2;
            this.Label_1_2.Text = "7";
            // 
            // Label_5_1
            // 
            this.Label_5_1.AutoSize = true;
            this.Label_5_1.BackColor = System.Drawing.Color.White;
            this.Label_5_1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_1.Location = new System.Drawing.Point(102, 405);
            this.Label_5_1.Name = "Label_5_1";
            this.Label_5_1.Size = new System.Drawing.Size(23, 25);
            this.Label_5_1.TabIndex = 2;
            this.Label_5_1.Text = "0";
            // 
            // Label_0_6
            // 
            this.Label_0_6.AutoSize = true;
            this.Label_0_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_0_6.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_6.Location = new System.Drawing.Point(494, 52);
            this.Label_0_6.Name = "Label_0_6";
            this.Label_0_6.Size = new System.Drawing.Size(23, 25);
            this.Label_0_6.TabIndex = 2;
            this.Label_0_6.Text = "4";
            // 
            // Label_4_1
            // 
            this.Label_4_1.AutoSize = true;
            this.Label_4_1.BackColor = System.Drawing.Color.White;
            this.Label_4_1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_1.Location = new System.Drawing.Point(102, 333);
            this.Label_4_1.Name = "Label_4_1";
            this.Label_4_1.Size = new System.Drawing.Size(34, 25);
            this.Label_4_1.TabIndex = 2;
            this.Label_4_1.Text = "27";
            // 
            // Label_0_5
            // 
            this.Label_0_5.AutoSize = true;
            this.Label_0_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.Label_0_5.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_5.Location = new System.Drawing.Point(414, 52);
            this.Label_0_5.Name = "Label_0_5";
            this.Label_0_5.Size = new System.Drawing.Size(23, 25);
            this.Label_0_5.TabIndex = 2;
            this.Label_0_5.Text = "3";
            // 
            // Label_3_1
            // 
            this.Label_3_1.AutoSize = true;
            this.Label_3_1.BackColor = System.Drawing.Color.White;
            this.Label_3_1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_1.Location = new System.Drawing.Point(102, 262);
            this.Label_3_1.Name = "Label_3_1";
            this.Label_3_1.Size = new System.Drawing.Size(34, 25);
            this.Label_3_1.TabIndex = 2;
            this.Label_3_1.Text = "20";
            // 
            // Label_0_3
            // 
            this.Label_0_3.AutoSize = true;
            this.Label_0_3.BackColor = System.Drawing.Color.White;
            this.Label_0_3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_3.Location = new System.Drawing.Point(258, 52);
            this.Label_0_3.Name = "Label_0_3";
            this.Label_0_3.Size = new System.Drawing.Size(23, 25);
            this.Label_0_3.TabIndex = 2;
            this.Label_0_3.Text = "1";
            // 
            // Label_5_0
            // 
            this.Label_5_0.AutoSize = true;
            this.Label_5_0.BackColor = System.Drawing.Color.White;
            this.Label_5_0.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_5_0.Location = new System.Drawing.Point(23, 405);
            this.Label_5_0.Name = "Label_5_0";
            this.Label_5_0.Size = new System.Drawing.Size(23, 25);
            this.Label_5_0.TabIndex = 2;
            this.Label_5_0.Text = "0";
            // 
            // Label_2_1
            // 
            this.Label_2_1.AutoSize = true;
            this.Label_2_1.BackColor = System.Drawing.Color.White;
            this.Label_2_1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_1.Location = new System.Drawing.Point(102, 192);
            this.Label_2_1.Name = "Label_2_1";
            this.Label_2_1.Size = new System.Drawing.Size(34, 25);
            this.Label_2_1.TabIndex = 2;
            this.Label_2_1.Text = "13";
            // 
            // Label_4_0
            // 
            this.Label_4_0.AutoSize = true;
            this.Label_4_0.BackColor = System.Drawing.Color.White;
            this.Label_4_0.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_4_0.Location = new System.Drawing.Point(23, 333);
            this.Label_4_0.Name = "Label_4_0";
            this.Label_4_0.Size = new System.Drawing.Size(34, 25);
            this.Label_4_0.TabIndex = 2;
            this.Label_4_0.Text = "26";
            // 
            // Label_0_4
            // 
            this.Label_0_4.AutoSize = true;
            this.Label_0_4.BackColor = System.Drawing.Color.White;
            this.Label_0_4.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_4.Location = new System.Drawing.Point(335, 52);
            this.Label_0_4.Name = "Label_0_4";
            this.Label_0_4.Size = new System.Drawing.Size(23, 25);
            this.Label_0_4.TabIndex = 2;
            this.Label_0_4.Text = "2";
            // 
            // Label_3_0
            // 
            this.Label_3_0.AutoSize = true;
            this.Label_3_0.BackColor = System.Drawing.Color.White;
            this.Label_3_0.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_3_0.Location = new System.Drawing.Point(23, 262);
            this.Label_3_0.Name = "Label_3_0";
            this.Label_3_0.Size = new System.Drawing.Size(34, 25);
            this.Label_3_0.TabIndex = 2;
            this.Label_3_0.Text = "19";
            // 
            // Label_1_1
            // 
            this.Label_1_1.AutoSize = true;
            this.Label_1_1.BackColor = System.Drawing.Color.White;
            this.Label_1_1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_1.Location = new System.Drawing.Point(102, 121);
            this.Label_1_1.Name = "Label_1_1";
            this.Label_1_1.Size = new System.Drawing.Size(23, 25);
            this.Label_1_1.TabIndex = 2;
            this.Label_1_1.Text = "6";
            // 
            // Label_2_0
            // 
            this.Label_2_0.AutoSize = true;
            this.Label_2_0.BackColor = System.Drawing.Color.White;
            this.Label_2_0.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_2_0.Location = new System.Drawing.Point(23, 192);
            this.Label_2_0.Name = "Label_2_0";
            this.Label_2_0.Size = new System.Drawing.Size(34, 25);
            this.Label_2_0.TabIndex = 2;
            this.Label_2_0.Text = "12";
            // 
            // Label_0_2
            // 
            this.Label_0_2.AutoSize = true;
            this.Label_0_2.BackColor = System.Drawing.Color.White;
            this.Label_0_2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_2.Location = new System.Drawing.Point(179, 52);
            this.Label_0_2.Name = "Label_0_2";
            this.Label_0_2.Size = new System.Drawing.Size(23, 25);
            this.Label_0_2.TabIndex = 2;
            this.Label_0_2.Text = "0";
            // 
            // Label_1_0
            // 
            this.Label_1_0.AutoSize = true;
            this.Label_1_0.BackColor = System.Drawing.Color.White;
            this.Label_1_0.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_1_0.Location = new System.Drawing.Point(23, 121);
            this.Label_1_0.Name = "Label_1_0";
            this.Label_1_0.Size = new System.Drawing.Size(23, 25);
            this.Label_1_0.TabIndex = 2;
            this.Label_1_0.Text = "5";
            // 
            // Label_0_1
            // 
            this.Label_0_1.AutoSize = true;
            this.Label_0_1.BackColor = System.Drawing.Color.White;
            this.Label_0_1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_1.Location = new System.Drawing.Point(102, 52);
            this.Label_0_1.Name = "Label_0_1";
            this.Label_0_1.Size = new System.Drawing.Size(23, 25);
            this.Label_0_1.TabIndex = 2;
            this.Label_0_1.Text = "0";
            // 
            // Label_0_0
            // 
            this.Label_0_0.AutoSize = true;
            this.Label_0_0.BackColor = System.Drawing.Color.White;
            this.Label_0_0.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Label_0_0.Location = new System.Drawing.Point(24, 52);
            this.Label_0_0.Name = "Label_0_0";
            this.Label_0_0.Size = new System.Drawing.Size(23, 25);
            this.Label_0_0.TabIndex = 2;
            this.Label_0_0.Text = "0";
            // 
            // Lab_Sunday
            // 
            this.Lab_Sunday.AutoSize = true;
            this.Lab_Sunday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Sunday.ForeColor = System.Drawing.Color.DarkMagenta;
            this.Lab_Sunday.Location = new System.Drawing.Point(510, 26);
            this.Lab_Sunday.Name = "Lab_Sunday";
            this.Lab_Sunday.Size = new System.Drawing.Size(52, 18);
            this.Lab_Sunday.TabIndex = 1;
            this.Lab_Sunday.Text = "Неділя";
            // 
            // Lab_Saturday
            // 
            this.Lab_Saturday.AutoSize = true;
            this.Lab_Saturday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Saturday.ForeColor = System.Drawing.Color.DarkMagenta;
            this.Lab_Saturday.Location = new System.Drawing.Point(429, 26);
            this.Lab_Saturday.Name = "Lab_Saturday";
            this.Lab_Saturday.Size = new System.Drawing.Size(57, 18);
            this.Lab_Saturday.TabIndex = 1;
            this.Lab_Saturday.Text = "Субота";
            // 
            // Lab_Friday
            // 
            this.Lab_Friday.AutoSize = true;
            this.Lab_Friday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Friday.Location = new System.Drawing.Point(339, 27);
            this.Lab_Friday.Name = "Lab_Friday";
            this.Lab_Friday.Size = new System.Drawing.Size(70, 18);
            this.Lab_Friday.TabIndex = 1;
            this.Lab_Friday.Text = "П\'ятниця";
            // 
            // Lab_Thursday
            // 
            this.Lab_Thursday.AutoSize = true;
            this.Lab_Thursday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Thursday.Location = new System.Drawing.Point(272, 27);
            this.Lab_Thursday.Name = "Lab_Thursday";
            this.Lab_Thursday.Size = new System.Drawing.Size(58, 18);
            this.Lab_Thursday.TabIndex = 1;
            this.Lab_Thursday.Text = "Четвер";
            // 
            // Lab_Wednesday
            // 
            this.Lab_Wednesday.AutoSize = true;
            this.Lab_Wednesday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Wednesday.Location = new System.Drawing.Point(197, 26);
            this.Lab_Wednesday.Name = "Lab_Wednesday";
            this.Lab_Wednesday.Size = new System.Drawing.Size(57, 18);
            this.Lab_Wednesday.TabIndex = 1;
            this.Lab_Wednesday.Text = "Середа";
            // 
            // Lab_Tuesday
            // 
            this.Lab_Tuesday.AutoSize = true;
            this.Lab_Tuesday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Tuesday.Location = new System.Drawing.Point(107, 26);
            this.Lab_Tuesday.Name = "Lab_Tuesday";
            this.Lab_Tuesday.Size = new System.Drawing.Size(66, 18);
            this.Lab_Tuesday.TabIndex = 1;
            this.Lab_Tuesday.Text = "Вівторок";
            // 
            // Lab_Monday
            // 
            this.Lab_Monday.AutoSize = true;
            this.Lab_Monday.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Monday.Location = new System.Drawing.Point(21, 26);
            this.Lab_Monday.Name = "Lab_Monday";
            this.Lab_Monday.Size = new System.Drawing.Size(75, 18);
            this.Lab_Monday.TabIndex = 1;
            this.Lab_Monday.Text = "Понеділок";
            // 
            // RTB_3_6
            // 
            this.RTB_3_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_3_6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_6.Location = new System.Drawing.Point(488, 259);
            this.RTB_3_6.Name = "RTB_3_6";
            this.RTB_3_6.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_6.TabIndex = 0;
            this.RTB_3_6.Text = "\n\n";
            // 
            // RTB_1_6
            // 
            this.RTB_1_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_1_6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_6.Location = new System.Drawing.Point(488, 118);
            this.RTB_1_6.Name = "RTB_1_6";
            this.RTB_1_6.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_6.TabIndex = 0;
            this.RTB_1_6.Text = "\n\n";
            // 
            // RTB_5_5
            // 
            this.RTB_5_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_5_5.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_5.Location = new System.Drawing.Point(410, 401);
            this.RTB_5_5.Name = "RTB_5_5";
            this.RTB_5_5.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_5.TabIndex = 0;
            this.RTB_5_5.Text = "\n\n";
            // 
            // RTB_3_5
            // 
            this.RTB_3_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_3_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_5.Location = new System.Drawing.Point(410, 259);
            this.RTB_3_5.Name = "RTB_3_5";
            this.RTB_3_5.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_5.TabIndex = 0;
            this.RTB_3_5.Text = "\n\n";
            // 
            // RTB_1_5
            // 
            this.RTB_1_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_1_5.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_5.Location = new System.Drawing.Point(410, 118);
            this.RTB_1_5.Name = "RTB_1_5";
            this.RTB_1_5.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.RTB_1_5.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_5.TabIndex = 0;
            this.RTB_1_5.Text = "\n\n";
            // 
            // RTB_5_3
            // 
            this.RTB_5_3.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_3.Location = new System.Drawing.Point(254, 401);
            this.RTB_5_3.Name = "RTB_5_3";
            this.RTB_5_3.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_3.TabIndex = 0;
            this.RTB_5_3.Text = "\n\n";
            // 
            // RTB_3_3
            // 
            this.RTB_3_3.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_3.Location = new System.Drawing.Point(254, 259);
            this.RTB_3_3.Name = "RTB_3_3";
            this.RTB_3_3.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_3.TabIndex = 0;
            this.RTB_3_3.Text = "\n\n";
            // 
            // RTB_1_3
            // 
            this.RTB_1_3.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_3.Location = new System.Drawing.Point(254, 118);
            this.RTB_1_3.Name = "RTB_1_3";
            this.RTB_1_3.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_3.TabIndex = 0;
            this.RTB_1_3.Text = "\n\n";
            // 
            // RTB_5_1
            // 
            this.RTB_5_1.Font = new System.Drawing.Font("Franklin Gothic Demi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_1.Location = new System.Drawing.Point(98, 401);
            this.RTB_5_1.Name = "RTB_5_1";
            this.RTB_5_1.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_1.TabIndex = 0;
            this.RTB_5_1.Text = "\n\n";
            // 
            // RTB_3_1
            // 
            this.RTB_3_1.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_1.Location = new System.Drawing.Point(98, 259);
            this.RTB_3_1.Name = "RTB_3_1";
            this.RTB_3_1.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_1.TabIndex = 0;
            this.RTB_3_1.Text = "\n\n";
            // 
            // RTB_1_1
            // 
            this.RTB_1_1.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_1.Location = new System.Drawing.Point(98, 118);
            this.RTB_1_1.Name = "RTB_1_1";
            this.RTB_1_1.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_1.TabIndex = 0;
            this.RTB_1_1.Text = "\n\n";
            // 
            // RTB_4_6
            // 
            this.RTB_4_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_4_6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_6.Location = new System.Drawing.Point(488, 330);
            this.RTB_4_6.Name = "RTB_4_6";
            this.RTB_4_6.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_6.TabIndex = 0;
            this.RTB_4_6.Text = "\n\n";
            this.RTB_4_6.TextChanged += new System.EventHandler(this.richTextBox37_TextChanged);
            // 
            // RTB_2_6
            // 
            this.RTB_2_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_2_6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_6.Location = new System.Drawing.Point(488, 188);
            this.RTB_2_6.Name = "RTB_2_6";
            this.RTB_2_6.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_6.TabIndex = 0;
            this.RTB_2_6.Text = "\n\n";
            // 
            // RTB_0_6
            // 
            this.RTB_0_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_0_6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_6.Location = new System.Drawing.Point(488, 47);
            this.RTB_0_6.Name = "RTB_0_6";
            this.RTB_0_6.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_6.TabIndex = 0;
            this.RTB_0_6.Text = "\n\n";
            // 
            // RTB_4_5
            // 
            this.RTB_4_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_4_5.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_5.Location = new System.Drawing.Point(410, 330);
            this.RTB_4_5.Name = "RTB_4_5";
            this.RTB_4_5.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_5.TabIndex = 0;
            this.RTB_4_5.Text = "\n\n";
            // 
            // RTB_2_5
            // 
            this.RTB_2_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_2_5.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_5.Location = new System.Drawing.Point(410, 188);
            this.RTB_2_5.Name = "RTB_2_5";
            this.RTB_2_5.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_5.TabIndex = 0;
            this.RTB_2_5.Text = "\n\n";
            // 
            // RTB_0_5
            // 
            this.RTB_0_5.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_0_5.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_5.Location = new System.Drawing.Point(410, 47);
            this.RTB_0_5.Name = "RTB_0_5";
            this.RTB_0_5.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_5.TabIndex = 0;
            this.RTB_0_5.Text = "\n\n";
            // 
            // RTB_5_4
            // 
            this.RTB_5_4.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_4.Location = new System.Drawing.Point(332, 401);
            this.RTB_5_4.Name = "RTB_5_4";
            this.RTB_5_4.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_4.TabIndex = 0;
            this.RTB_5_4.Text = "\n\n";
            // 
            // RTB_3_4
            // 
            this.RTB_3_4.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_4.Location = new System.Drawing.Point(332, 259);
            this.RTB_3_4.Name = "RTB_3_4";
            this.RTB_3_4.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_4.TabIndex = 0;
            this.RTB_3_4.Text = "\n\n";
            this.RTB_3_4.TextChanged += new System.EventHandler(this.richTextBox21_TextChanged);
            // 
            // RTB_1_4
            // 
            this.RTB_1_4.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_4.Location = new System.Drawing.Point(332, 118);
            this.RTB_1_4.Name = "RTB_1_4";
            this.RTB_1_4.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_4.TabIndex = 0;
            this.RTB_1_4.Text = "\n\n";
            // 
            // RTB_4_3
            // 
            this.RTB_4_3.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_3.Location = new System.Drawing.Point(254, 330);
            this.RTB_4_3.Name = "RTB_4_3";
            this.RTB_4_3.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_3.TabIndex = 0;
            this.RTB_4_3.Text = "\n\n";
            // 
            // RTB_2_3
            // 
            this.RTB_2_3.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_3.Location = new System.Drawing.Point(254, 188);
            this.RTB_2_3.Name = "RTB_2_3";
            this.RTB_2_3.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_3.TabIndex = 0;
            this.RTB_2_3.Text = "\n\n";
            // 
            // RTB_0_3
            // 
            this.RTB_0_3.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_3.Location = new System.Drawing.Point(254, 47);
            this.RTB_0_3.Name = "RTB_0_3";
            this.RTB_0_3.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_3.TabIndex = 0;
            this.RTB_0_3.Text = "\n\n";
            // 
            // RTB_5_2
            // 
            this.RTB_5_2.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_2.Location = new System.Drawing.Point(176, 401);
            this.RTB_5_2.Name = "RTB_5_2";
            this.RTB_5_2.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_2.TabIndex = 0;
            this.RTB_5_2.Text = "\n\n";
            // 
            // RTB_3_2
            // 
            this.RTB_3_2.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_2.Location = new System.Drawing.Point(176, 259);
            this.RTB_3_2.Name = "RTB_3_2";
            this.RTB_3_2.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_2.TabIndex = 0;
            this.RTB_3_2.Text = "\n\n";
            this.RTB_3_2.TextChanged += new System.EventHandler(this.richTextBox19_TextChanged);
            // 
            // RTB_1_2
            // 
            this.RTB_1_2.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_2.Location = new System.Drawing.Point(176, 118);
            this.RTB_1_2.Name = "RTB_1_2";
            this.RTB_1_2.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_2.TabIndex = 0;
            this.RTB_1_2.Text = "\n\n";
            // 
            // RTB_4_4
            // 
            this.RTB_4_4.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_4.Location = new System.Drawing.Point(332, 330);
            this.RTB_4_4.Name = "RTB_4_4";
            this.RTB_4_4.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_4.TabIndex = 0;
            this.RTB_4_4.Text = "\n\n";
            // 
            // RTB_2_4
            // 
            this.RTB_2_4.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_4.Location = new System.Drawing.Point(332, 188);
            this.RTB_2_4.Name = "RTB_2_4";
            this.RTB_2_4.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_4.TabIndex = 0;
            this.RTB_2_4.Text = "\n\n";
            // 
            // RTB_0_4
            // 
            this.RTB_0_4.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_4.Location = new System.Drawing.Point(332, 47);
            this.RTB_0_4.Name = "RTB_0_4";
            this.RTB_0_4.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_4.TabIndex = 0;
            this.RTB_0_4.Text = "\n\n";
            // 
            // RTB_4_1
            // 
            this.RTB_4_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_1.Location = new System.Drawing.Point(98, 330);
            this.RTB_4_1.Name = "RTB_4_1";
            this.RTB_4_1.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_1.TabIndex = 0;
            this.RTB_4_1.Text = "\n\n";
            // 
            // RTB_2_1
            // 
            this.RTB_2_1.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_1.Location = new System.Drawing.Point(98, 188);
            this.RTB_2_1.Name = "RTB_2_1";
            this.RTB_2_1.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_1.TabIndex = 0;
            this.RTB_2_1.Text = "\n\n";
            // 
            // RTB_0_1
            // 
            this.RTB_0_1.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_1.Location = new System.Drawing.Point(98, 47);
            this.RTB_0_1.Name = "RTB_0_1";
            this.RTB_0_1.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_1.TabIndex = 0;
            this.RTB_0_1.Text = "\n\n";
            // 
            // RTB_4_2
            // 
            this.RTB_4_2.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_2.Location = new System.Drawing.Point(176, 330);
            this.RTB_4_2.Name = "RTB_4_2";
            this.RTB_4_2.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_2.TabIndex = 0;
            this.RTB_4_2.Text = "\n\n";
            // 
            // RTB_2_2
            // 
            this.RTB_2_2.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_2.Location = new System.Drawing.Point(176, 188);
            this.RTB_2_2.Name = "RTB_2_2";
            this.RTB_2_2.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_2.TabIndex = 0;
            this.RTB_2_2.Text = "\n\n";
            // 
            // RTB_0_2
            // 
            this.RTB_0_2.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_2.Location = new System.Drawing.Point(176, 47);
            this.RTB_0_2.Name = "RTB_0_2";
            this.RTB_0_2.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_2.TabIndex = 0;
            this.RTB_0_2.Text = "\n\n";
            // 
            // RTB_5_0
            // 
            this.RTB_5_0.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_0.Location = new System.Drawing.Point(20, 401);
            this.RTB_5_0.Name = "RTB_5_0";
            this.RTB_5_0.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_0.TabIndex = 0;
            this.RTB_5_0.Text = "\n\n";
            // 
            // RTB_4_0
            // 
            this.RTB_4_0.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_4_0.Location = new System.Drawing.Point(20, 330);
            this.RTB_4_0.Name = "RTB_4_0";
            this.RTB_4_0.Size = new System.Drawing.Size(78, 71);
            this.RTB_4_0.TabIndex = 0;
            this.RTB_4_0.Text = "\n\n";
            // 
            // RTB_3_0
            // 
            this.RTB_3_0.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_3_0.Location = new System.Drawing.Point(20, 259);
            this.RTB_3_0.Name = "RTB_3_0";
            this.RTB_3_0.Size = new System.Drawing.Size(78, 71);
            this.RTB_3_0.TabIndex = 0;
            this.RTB_3_0.Text = "\n\n";
            this.RTB_3_0.TextChanged += new System.EventHandler(this.richTextBox15_TextChanged);
            // 
            // RTB_2_0
            // 
            this.RTB_2_0.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_2_0.Location = new System.Drawing.Point(20, 188);
            this.RTB_2_0.Name = "RTB_2_0";
            this.RTB_2_0.Size = new System.Drawing.Size(78, 71);
            this.RTB_2_0.TabIndex = 0;
            this.RTB_2_0.Text = "\n\n";
            // 
            // RTB_1_0
            // 
            this.RTB_1_0.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_1_0.Location = new System.Drawing.Point(20, 118);
            this.RTB_1_0.Name = "RTB_1_0";
            this.RTB_1_0.Size = new System.Drawing.Size(78, 71);
            this.RTB_1_0.TabIndex = 0;
            this.RTB_1_0.Text = "\n\n";
            // 
            // RTB_0_0
            // 
            this.RTB_0_0.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_0_0.Location = new System.Drawing.Point(20, 47);
            this.RTB_0_0.Name = "RTB_0_0";
            this.RTB_0_0.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RTB_0_0.Size = new System.Drawing.Size(78, 71);
            this.RTB_0_0.TabIndex = 0;
            this.RTB_0_0.Text = "\n\n";
            this.RTB_0_0.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // RTB_5_6
            // 
            this.RTB_5_6.BackColor = System.Drawing.Color.NavajoWhite;
            this.RTB_5_6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RTB_5_6.Location = new System.Drawing.Point(488, 401);
            this.RTB_5_6.Name = "RTB_5_6";
            this.RTB_5_6.Size = new System.Drawing.Size(78, 71);
            this.RTB_5_6.TabIndex = 0;
            this.RTB_5_6.Text = "\n\n";
            this.RTB_5_6.TextChanged += new System.EventHandler(this.richTextBox41_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(308, 291);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(633, -1);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(329, 291);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(583, 405);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(379, 367);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // Lab_Month_Oct
            // 
            this.Lab_Month_Oct.AutoSize = true;
            this.Lab_Month_Oct.Font = new System.Drawing.Font("Mistral", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_Month_Oct.ForeColor = System.Drawing.Color.Black;
            this.Lab_Month_Oct.Location = new System.Drawing.Point(359, 26);
            this.Lab_Month_Oct.Name = "Lab_Month_Oct";
            this.Lab_Month_Oct.Size = new System.Drawing.Size(222, 76);
            this.Lab_Month_Oct.TabIndex = 2;
            this.Lab_Month_Oct.Text = "Жовтень";
            // 
            // Lab_year_2020
            // 
            this.Lab_year_2020.AutoSize = true;
            this.Lab_year_2020.Font = new System.Drawing.Font("Trebuchet MS", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lab_year_2020.ForeColor = System.Drawing.Color.Goldenrod;
            this.Lab_year_2020.Location = new System.Drawing.Point(562, 17);
            this.Lab_year_2020.Name = "Lab_year_2020";
            this.Lab_year_2020.Size = new System.Drawing.Size(103, 43);
            this.Lab_year_2020.TabIndex = 2;
            this.Lab_year_2020.Text = "2020";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BusyHours);
            this.groupBox3.Controls.Add(this.BusyDays);
            this.groupBox3.Controls.Add(this.FreeHours);
            this.groupBox3.Controls.Add(this.FreeDays);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button_selected_Date);
            this.groupBox3.Controls.Add(this.Lab_Calculate);
            this.groupBox3.Controls.Add(this.Calculate_work);
            this.groupBox3.Location = new System.Drawing.Point(3, 254);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 516);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            // 
            // BusyHours
            // 
            this.BusyHours.AutoSize = true;
            this.BusyHours.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BusyHours.Location = new System.Drawing.Point(111, 174);
            this.BusyHours.Name = "BusyHours";
            this.BusyHours.Size = new System.Drawing.Size(16, 17);
            this.BusyHours.TabIndex = 5;
            this.BusyHours.Text = "0";
            // 
            // BusyDays
            // 
            this.BusyDays.AutoSize = true;
            this.BusyDays.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BusyDays.Location = new System.Drawing.Point(111, 151);
            this.BusyDays.Name = "BusyDays";
            this.BusyDays.Size = new System.Drawing.Size(16, 17);
            this.BusyDays.TabIndex = 5;
            this.BusyDays.Text = "0";
            // 
            // FreeHours
            // 
            this.FreeHours.AutoSize = true;
            this.FreeHours.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FreeHours.Location = new System.Drawing.Point(111, 115);
            this.FreeHours.Name = "FreeHours";
            this.FreeHours.Size = new System.Drawing.Size(16, 17);
            this.FreeHours.TabIndex = 5;
            this.FreeHours.Text = "0";
            // 
            // FreeDays
            // 
            this.FreeDays.AutoSize = true;
            this.FreeDays.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FreeDays.Location = new System.Drawing.Point(111, 93);
            this.FreeDays.Name = "FreeDays";
            this.FreeDays.Size = new System.Drawing.Size(16, 17);
            this.FreeDays.TabIndex = 5;
            this.FreeDays.Text = "0";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(0, 200);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(197, 20);
            this.textBox1.TabIndex = 4;
            this.textBox1.Tag = "";
            this.textBox1.Leave += new System.EventHandler(this.onFocusLeave);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker1.Location = new System.Drawing.Point(3, 226);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(194, 21);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Thistle;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.Font = new System.Drawing.Font("Franklin Gothic Book", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.Purple;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(4, 298);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(192, 67);
            this.button3.TabIndex = 2;
            this.button3.Text = "Вийти";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.onExit);
            // 
            // button_selected_Date
            // 
            this.button_selected_Date.BackColor = System.Drawing.Color.Goldenrod;
            this.button_selected_Date.FlatAppearance.BorderSize = 0;
            this.button_selected_Date.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_selected_Date.Font = new System.Drawing.Font("Franklin Gothic Book", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_selected_Date.ForeColor = System.Drawing.Color.Purple;
            this.button_selected_Date.Location = new System.Drawing.Point(3, 252);
            this.button_selected_Date.Name = "button_selected_Date";
            this.button_selected_Date.Size = new System.Drawing.Size(193, 33);
            this.button_selected_Date.TabIndex = 0;
            this.button_selected_Date.Text = "Обрати дату";
            this.button_selected_Date.UseVisualStyleBackColor = false;
            this.button_selected_Date.Click += new System.EventHandler(this.changeDate);
            // 
            // Lab_Calculate
            // 
            this.Lab_Calculate.AutoSize = true;
            this.Lab_Calculate.Font = new System.Drawing.Font("Franklin Gothic Book", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lab_Calculate.ForeColor = System.Drawing.Color.Peru;
            this.Lab_Calculate.Location = new System.Drawing.Point(0, 71);
            this.Lab_Calculate.Name = "Lab_Calculate";
            this.Lab_Calculate.Size = new System.Drawing.Size(105, 120);
            this.Lab_Calculate.TabIndex = 1;
            this.Lab_Calculate.Text = "Розрахунок:\r\nВільних днів:\r\n           годин:\r\n\r\nЗайнятих днів:\r\n              го" +
    "дин:";
            // 
            // Calculate_work
            // 
            this.Calculate_work.BackColor = System.Drawing.Color.BurlyWood;
            this.Calculate_work.FlatAppearance.BorderSize = 0;
            this.Calculate_work.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Calculate_work.Font = new System.Drawing.Font("Franklin Gothic Book", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Calculate_work.ForeColor = System.Drawing.Color.Purple;
            this.Calculate_work.Image = ((System.Drawing.Image)(resources.GetObject("Calculate_work.Image")));
            this.Calculate_work.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Calculate_work.Location = new System.Drawing.Point(3, 15);
            this.Calculate_work.Name = "Calculate_work";
            this.Calculate_work.Size = new System.Drawing.Size(194, 48);
            this.Calculate_work.TabIndex = 0;
            this.Calculate_work.Text = "Розрахувати \r\nнавантаження";
            this.Calculate_work.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Calculate_work.UseVisualStyleBackColor = false;
            this.Calculate_work.Click += new System.EventHandler(this.button2_Click);
            // 
            // Name_KA
            // 
            this.Name_KA.AutoSize = true;
            this.Name_KA.Font = new System.Drawing.Font("Segoe Script", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name_KA.ForeColor = System.Drawing.Color.Purple;
            this.Name_KA.Location = new System.Drawing.Point(803, 306);
            this.Name_KA.Name = "Name_KA";
            this.Name_KA.Size = new System.Drawing.Size(154, 76);
            this.Name_KA.TabIndex = 4;
            this.Name_KA.Text = "Koronenko\r\nAnastasiia";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.addEvent);
            this.groupBox2.Controls.Add(this.displayEvent);
            this.groupBox2.Controls.Add(this.textEvent);
            this.groupBox2.Controls.Add(this.timeEvent);
            this.groupBox2.Controls.Add(this.dateEvent);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Font = new System.Drawing.Font("Franklin Gothic Book", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.ForeColor = System.Drawing.Color.Purple;
            this.groupBox2.Location = new System.Drawing.Point(210, 626);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(371, 146);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Додати подію";
            // 
            // addEvent
            // 
            this.addEvent.BackColor = System.Drawing.Color.BurlyWood;
            this.addEvent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEvent.Font = new System.Drawing.Font("Franklin Gothic Book", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addEvent.Location = new System.Drawing.Point(154, 77);
            this.addEvent.Name = "addEvent";
            this.addEvent.Size = new System.Drawing.Size(66, 43);
            this.addEvent.TabIndex = 7;
            this.addEvent.Text = "Додати";
            this.addEvent.UseVisualStyleBackColor = true;
            this.addEvent.Click += new System.EventHandler(this.addEvent_Click);
            // 
            // displayEvent
            // 
            this.displayEvent.BackColor = System.Drawing.Color.AntiqueWhite;
            this.displayEvent.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.displayEvent.Location = new System.Drawing.Point(221, 62);
            this.displayEvent.Multiline = true;
            this.displayEvent.Name = "displayEvent";
            this.displayEvent.ReadOnly = true;
            this.displayEvent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.displayEvent.Size = new System.Drawing.Size(144, 72);
            this.displayEvent.TabIndex = 8;
            // 
            // textEvent
            // 
            this.textEvent.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textEvent.Location = new System.Drawing.Point(9, 62);
            this.textEvent.Multiline = true;
            this.textEvent.Name = "textEvent";
            this.textEvent.Size = new System.Drawing.Size(144, 72);
            this.textEvent.TabIndex = 6;
            this.textEvent.Text = "Подія :";
            // 
            // timeEvent
            // 
            this.timeEvent.Font = new System.Drawing.Font("Franklin Gothic Book", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.timeEvent.Location = new System.Drawing.Point(266, 24);
            this.timeEvent.Mask = "00:00";
            this.timeEvent.Name = "timeEvent";
            this.timeEvent.Size = new System.Drawing.Size(100, 20);
            this.timeEvent.TabIndex = 5;
            this.timeEvent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.timeEvent.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.timeEvent_MaskInputRejected);
            // 
            // dateEvent
            // 
            this.dateEvent.CalendarFont = new System.Drawing.Font("Franklin Gothic Book", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateEvent.Font = new System.Drawing.Font("Franklin Gothic Book", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateEvent.Location = new System.Drawing.Point(71, 24);
            this.dateEvent.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateEvent.Name = "dateEvent";
            this.dateEvent.Size = new System.Drawing.Size(127, 20);
            this.dateEvent.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Peru;
            this.label6.Location = new System.Drawing.Point(205, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "Час події";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Franklin Gothic Book", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.Peru;
            this.label5.Location = new System.Drawing.Point(6, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Дата події";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 772);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Name_KA);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.Lab_year_2020);
            this.Controls.Add(this.Lab_Month_Oct);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scheduler";
            this.Load += new System.EventHandler(this.changeDate);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox RTB_0_0;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RichTextBox RTB_5_6;
        private System.Windows.Forms.RichTextBox RTB_3_6;
        private System.Windows.Forms.RichTextBox RTB_1_6;
        private System.Windows.Forms.RichTextBox RTB_5_5;
        private System.Windows.Forms.RichTextBox RTB_3_5;
        private System.Windows.Forms.RichTextBox RTB_1_5;
        private System.Windows.Forms.RichTextBox RTB_5_3;
        private System.Windows.Forms.RichTextBox RTB_3_3;
        private System.Windows.Forms.RichTextBox RTB_1_3;
        private System.Windows.Forms.RichTextBox RTB_5_1;
        private System.Windows.Forms.RichTextBox RTB_3_1;
        private System.Windows.Forms.RichTextBox RTB_1_1;
        private System.Windows.Forms.RichTextBox RTB_4_6;
        private System.Windows.Forms.RichTextBox RTB_2_6;
        private System.Windows.Forms.RichTextBox RTB_0_6;
        private System.Windows.Forms.RichTextBox RTB_4_5;
        private System.Windows.Forms.RichTextBox RTB_2_5;
        private System.Windows.Forms.RichTextBox RTB_0_5;
        private System.Windows.Forms.RichTextBox RTB_5_4;
        private System.Windows.Forms.RichTextBox RTB_3_4;
        private System.Windows.Forms.RichTextBox RTB_1_4;
        private System.Windows.Forms.RichTextBox RTB_4_3;
        private System.Windows.Forms.RichTextBox RTB_2_3;
        private System.Windows.Forms.RichTextBox RTB_0_3;
        private System.Windows.Forms.RichTextBox RTB_5_2;
        private System.Windows.Forms.RichTextBox RTB_3_2;
        private System.Windows.Forms.RichTextBox RTB_1_2;
        private System.Windows.Forms.RichTextBox RTB_4_4;
        private System.Windows.Forms.RichTextBox RTB_2_4;
        private System.Windows.Forms.RichTextBox RTB_0_4;
        private System.Windows.Forms.RichTextBox RTB_4_1;
        private System.Windows.Forms.RichTextBox RTB_2_1;
        private System.Windows.Forms.RichTextBox RTB_0_1;
        private System.Windows.Forms.RichTextBox RTB_4_2;
        private System.Windows.Forms.RichTextBox RTB_2_2;
        private System.Windows.Forms.RichTextBox RTB_0_2;
        private System.Windows.Forms.RichTextBox RTB_5_0;
        private System.Windows.Forms.RichTextBox RTB_4_0;
        private System.Windows.Forms.RichTextBox RTB_3_0;
        private System.Windows.Forms.RichTextBox RTB_2_0;
        private System.Windows.Forms.RichTextBox RTB_1_0;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label Lab_Sunday;
        private System.Windows.Forms.Label Lab_Saturday;
        private System.Windows.Forms.Label Lab_Friday;
        private System.Windows.Forms.Label Lab_Thursday;
        private System.Windows.Forms.Label Lab_Wednesday;
        private System.Windows.Forms.Label Lab_Tuesday;
        private System.Windows.Forms.Label Lab_Monday;
        private System.Windows.Forms.Label Label_1_6;
        private System.Windows.Forms.Label Label_1_5;
        private System.Windows.Forms.Label Label_1_3;
        private System.Windows.Forms.Label Label_1_4;
        private System.Windows.Forms.Label Label_1_2;
        private System.Windows.Forms.Label Label_0_6;
        private System.Windows.Forms.Label Label_0_5;
        private System.Windows.Forms.Label Label_0_3;
        private System.Windows.Forms.Label Label_0_4;
        private System.Windows.Forms.Label Label_1_1;
        private System.Windows.Forms.Label Label_0_2;
        private System.Windows.Forms.Label Label_1_0;
        private System.Windows.Forms.Label Label_0_1;
        private System.Windows.Forms.Label Label_0_0;
        private System.Windows.Forms.Label Label_5_6;
        private System.Windows.Forms.Label Label_5_5;
        private System.Windows.Forms.Label Label_4_6;
        private System.Windows.Forms.Label Label_4_5;
        private System.Windows.Forms.Label Label_3_6;
        private System.Windows.Forms.Label Label_3_5;
        private System.Windows.Forms.Label Label_5_3;
        private System.Windows.Forms.Label Label_2_6;
        private System.Windows.Forms.Label Label_4_3;
        private System.Windows.Forms.Label Label_2_5;
        private System.Windows.Forms.Label Label_3_3;
        private System.Windows.Forms.Label Label_5_4;
        private System.Windows.Forms.Label Label_4_4;
        private System.Windows.Forms.Label Label_2_3;
        private System.Windows.Forms.Label Label_3_4;
        private System.Windows.Forms.Label Label_5_2;
        private System.Windows.Forms.Label Label_4_2;
        private System.Windows.Forms.Label Label_2_4;
        private System.Windows.Forms.Label Label_3_2;
        private System.Windows.Forms.Label Label_2_2;
        private System.Windows.Forms.Label Label_5_1;
        private System.Windows.Forms.Label Label_4_1;
        private System.Windows.Forms.Label Label_3_1;
        private System.Windows.Forms.Label Label_5_0;
        private System.Windows.Forms.Label Label_2_1;
        private System.Windows.Forms.Label Label_4_0;
        private System.Windows.Forms.Label Label_3_0;
        private System.Windows.Forms.Label Label_2_0;
        private System.Windows.Forms.Label Lab_Month_Oct;
        private System.Windows.Forms.Label Lab_year_2020;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label Name_KA;
        private System.Windows.Forms.Button button_selected_Date;
        private System.Windows.Forms.Button Calculate_work;
        private System.Windows.Forms.Label Lab_Calculate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label BusyHours;
        private System.Windows.Forms.Label BusyDays;
        private System.Windows.Forms.Label FreeHours;
        private System.Windows.Forms.Label FreeDays;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateEvent;
        private System.Windows.Forms.MaskedTextBox timeEvent;
        private System.Windows.Forms.TextBox displayEvent;
        private System.Windows.Forms.TextBox textEvent;
        private System.Windows.Forms.Button addEvent;
    }
}

