﻿using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Globalization;

namespace WF_Calendar
{
    public partial class Form1 : Form
    {
        private FileOperation fileOperation;
        public Form1()
        {
            InitializeComponent();
            fileOperation = new FileOperation();
            fileOperation.Load();
        }


        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox41_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox37_TextChanged(object sender, EventArgs e)
        {

        }

        private void changeDateLabel_Month(DateTime selectedDate)
        {
            Lab_year_2020.Text = selectedDate.Year.ToString();

            switch (selectedDate.Month)
            {
                case 1:
                    Lab_Month_Oct.Text = "Сiчень";
                    break;
                case 2:
                    Lab_Month_Oct.Text = "Лютий";
                    break;
                case 3:
                    Lab_Month_Oct.Text = "Березень";
                    break;
                case 4:
                    Lab_Month_Oct.Text = "Квiтень";
                    break;
                case 5:
                    Lab_Month_Oct.Text = "Травень";
                    break;
                case 6:
                    Lab_Month_Oct.Text = "Червень";
                    break;
                case 7:
                    Lab_Month_Oct.Text = "Липень";
                    break;
                case 8:
                    Lab_Month_Oct.Text = "Серпень";
                    break;
                case 9:
                    Lab_Month_Oct.Text = "Вересень";
                    break;
                case 10:
                    Lab_Month_Oct.Text = "Жовтень";
                    break;
                case 11:
                    Lab_Month_Oct.Text = "Листопад";
                    break;
                case 12:
                    Lab_Month_Oct.Text = "Грудень";
                    break;
            }
        }
        private void changeDate(object sender, EventArgs e)
        {
            DateTime selectedDate = dateTimePicker1.Value;
            changeDateLabel_Month(selectedDate);
            Console.WriteLine(selectedDate);
            DateTime firstDay = new DateTime(selectedDate.Year, selectedDate.Month, 1);
            Console.WriteLine(firstDay);
            Console.WriteLine(firstDay.DayOfWeek);
            int dayOfWeek = 0;
            switch (firstDay.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    dayOfWeek = 0;
                    break;
                case DayOfWeek.Tuesday:
                    dayOfWeek = 1;
                    break;
                case DayOfWeek.Wednesday:
                    dayOfWeek = 2;
                    break;
                case DayOfWeek.Thursday:
                    dayOfWeek = 3;
                    break;
                case DayOfWeek.Friday:
                    dayOfWeek = 4;
                    break;
                case DayOfWeek.Saturday:
                    dayOfWeek = 5;
                    break;
                case DayOfWeek.Sunday:
                    dayOfWeek = 6;
                    break;
            }
            firstDay = firstDay.AddDays(-dayOfWeek);
            
            for (int i = 0; i < 42; i++, firstDay = firstDay.AddDays(1))
            {
                int row = i / 7;
                int column = i % 7;
                switch (row)
                {
                    case 0:
                        switch (column)
                        {
                            case 0:
                                CalculateUiCell(Label_0_0, RTB_0_0, selectedDate, firstDay);
                                break;
                            case 1:
                                CalculateUiCell(Label_0_1, RTB_0_1, selectedDate, firstDay);
                                break;
                            case 2:
                                CalculateUiCell(Label_0_2, RTB_0_2, selectedDate, firstDay);
                                break;
                            case 3:
                                CalculateUiCell(Label_0_3, RTB_0_3, selectedDate, firstDay);
                                break;
                            case 4:
                                CalculateUiCell(Label_0_4, RTB_0_4, selectedDate, firstDay);
                                break;
                            case 5:
                                CalculateUiCell(Label_0_5, RTB_0_5, selectedDate, firstDay);
                                break;
                            case 6:
                                CalculateUiCell(Label_0_6, RTB_0_6, selectedDate, firstDay);
                                break;
                        }
                        break;

                    case 1:
                        switch (column)
                        {
                            case 0:
                                CalculateUiCell(Label_1_0, RTB_1_0, selectedDate, firstDay);
                                break;
                            case 1:
                                CalculateUiCell(Label_1_1, RTB_1_1, selectedDate, firstDay);
                                break;
                            case 2:
                                CalculateUiCell(Label_1_2, RTB_1_2, selectedDate, firstDay);
                                break;
                            case 3:
                                CalculateUiCell(Label_1_3, RTB_1_3, selectedDate, firstDay);
                                break;
                            case 4:
                                CalculateUiCell(Label_1_4, RTB_1_4, selectedDate, firstDay);
                                break;
                            case 5:
                                CalculateUiCell(Label_1_5, RTB_1_5, selectedDate, firstDay);
                                break;
                            case 6:
                                CalculateUiCell(Label_1_6, RTB_1_6, selectedDate, firstDay);
                                break;
                        }
                        break;

                    case 2:
                        switch (column)
                        {
                            case 0:
                                CalculateUiCell(Label_2_0, RTB_2_0, selectedDate, firstDay);
                                break;
                            case 1:
                                CalculateUiCell(Label_2_1, RTB_2_1, selectedDate, firstDay);
                                break;
                            case 2:
                                CalculateUiCell(Label_2_2, RTB_2_2, selectedDate, firstDay);
                                break;
                            case 3:
                                CalculateUiCell(Label_2_3, RTB_2_3, selectedDate, firstDay);
                                break;
                            case 4:
                                CalculateUiCell(Label_2_4, RTB_2_4, selectedDate, firstDay);
                                break;
                            case 5:
                                CalculateUiCell(Label_2_5, RTB_2_5, selectedDate, firstDay);
                                break;
                            case 6:
                                CalculateUiCell(Label_2_6, RTB_2_6, selectedDate, firstDay);
                                break;
                        }
                        break;

                    case 3:
                        switch (column)
                        {
                            case 0:
                                CalculateUiCell(Label_3_0, RTB_3_0, selectedDate, firstDay);
                                break;
                            case 1:
                                CalculateUiCell(Label_3_1, RTB_3_1, selectedDate, firstDay);
                                break;
                            case 2:
                                CalculateUiCell(Label_3_2, RTB_3_2, selectedDate, firstDay);
                                break;
                            case 3:
                                CalculateUiCell(Label_3_3, RTB_3_3, selectedDate, firstDay);
                                break;
                            case 4:
                                CalculateUiCell(Label_3_4, RTB_3_4, selectedDate, firstDay);
                                break;
                            case 5:
                                CalculateUiCell(Label_3_5, RTB_3_5, selectedDate, firstDay);
                                break;
                            case 6:
                                CalculateUiCell(Label_3_6, RTB_3_6, selectedDate, firstDay);
                                break;
                        }
                        break;

                    case 4:
                        switch (column)
                        {
                            case 0:
                                CalculateUiCell(Label_4_0, RTB_4_0, selectedDate, firstDay);
                                break;
                            case 1:
                                CalculateUiCell(Label_4_1, RTB_4_1, selectedDate, firstDay);
                                break;
                            case 2:
                                CalculateUiCell(Label_4_2, RTB_4_2, selectedDate, firstDay);
                                break;
                            case 3:
                                CalculateUiCell(Label_4_3, RTB_4_3, selectedDate, firstDay);
                                break;
                            case 4:
                                CalculateUiCell(Label_4_4, RTB_4_4, selectedDate, firstDay);
                                break;
                            case 5:
                                CalculateUiCell(Label_4_5, RTB_4_5, selectedDate, firstDay);
                                break;
                            case 6:
                                CalculateUiCell(Label_4_6, RTB_4_6, selectedDate, firstDay);
                                break;
                        }
                        break;

                    case 5:
                        switch (column)
                        {
                            case 0:
                                CalculateUiCell(Label_5_0, RTB_5_0, selectedDate, firstDay);
                                break;
                            case 1:
                                CalculateUiCell(Label_5_1, RTB_5_1, selectedDate, firstDay);
                                break;
                            case 2:
                                CalculateUiCell(Label_5_2, RTB_5_2, selectedDate, firstDay);
                                break;
                            case 3:
                                CalculateUiCell(Label_5_3, RTB_5_3, selectedDate, firstDay);
                                break;
                            case 4:
                                CalculateUiCell(Label_5_4, RTB_5_4, selectedDate, firstDay);
                                break;
                            case 5:
                                CalculateUiCell(Label_5_5, RTB_5_5, selectedDate, firstDay);
                                break;
                            case 6:
                                CalculateUiCell(Label_5_6, RTB_5_6, selectedDate, firstDay);
                                break;
                        }
                        break;
                }

            }
        }

        private Color CalculateCellColor(DateTime selectedDate, DateTime currentDay)
        {
            if (selectedDate > currentDay && (selectedDate.Day != currentDay.Day || selectedDate.Month != currentDay.Month || selectedDate.Year != currentDay.Year))
            {
                return Color.LightGray;
            }
            else if (currentDay.DayOfWeek == DayOfWeek.Saturday || currentDay.DayOfWeek == DayOfWeek.Sunday)
            {
                return Color.NavajoWhite;
            }
            else
                return Color.White;
        }

        private void CalculateUiCell(Label label, RichTextBox textBox, DateTime selectedDate, DateTime currentDate)
        {
            label.Visible = selectedDate.Month == currentDate.Month;
            textBox.Visible = label.Visible; // відображення в привязці до поточної дати
            //приховування зайвих елементів

            label.Text = currentDate.Day.ToString();
            //label.BackColor = textBox.BackColor = CalculateCellColor(selectedDate, currentDate);
            //заливка всіх дат сірим до сьогоднішньої
            label.BackColor = textBox.BackColor = CalculateCellColor(DateTime.Now, currentDate);
            textBox.Text = "\n\n" + fileOperation.GetEventByDate(currentDate);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int freeDays = 0 ;

            int busyDays = fileOperation.CountStatistics(dateTimePicker1.Value, out freeDays);

            FreeDays.Text = Convert.ToString(freeDays);
            BusyDays.Text = Convert.ToString(busyDays);
            FreeHours.Text = Convert.ToString(freeDays * 8);
            BusyHours.Text = Convert.ToString(busyDays * 8);
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void onFocusLeave(object sender, EventArgs e)
        {
            string iDate = textBox1.Text;
            DateTime oDate;
            DateTime selectedDate = dateTimePicker1.Value;
            // oDate = Convert.ToDateTime(iDate);
            //dateTimePicker1.Value = oDate;
            try
            {
                oDate = Convert.ToDateTime(iDate);
                dateTimePicker1.Value = oDate;
            }
            catch (Exception)
            {
                DialogResult res = MessageBox.Show("Формат дати: 05.05.20", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dateTimePicker1.Value = selectedDate;
            }
        }

        private void addEvent_Click(object sender, EventArgs e)
        {
            // Для всех операций с файлами рекомендуется программировать код внутри try-catch-finally блока, чтобы обрабатывать ошибки и исключения.
            EventCalendar currentEvent = new EventCalendar(dateEvent.Value.ToString("dd.MM.yy"), timeEvent.Text, textEvent.Text);
            if (!fileOperation.AddEvent(currentEvent))
            {
                MessageBox.Show("Формат має бути: 23:59", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                displayEvent.Text = currentEvent.Info();
                changeDate(sender, e);
            }
        }

        private void timeEvent_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void onExit(object sender, EventArgs e)
        {
            fileOperation.Save();
            this.Close();
        }
    }
    public class FileOperation
    {
        private EventCalendar[] events;

        public void Load()
        {
            events = new EventCalendar[0];
            string bufferString; // змінна для зчитування рядка
            try
            {
                using (StreamReader reader = new StreamReader("persist.txt", Encoding.UTF8))
                {
                    while (reader.Peek() != -1) // -1 це символ кінця файла. peek повертає код наступного символа
                    {
                        bufferString = reader.ReadLine().Trim();//видаляє whitespecsymbol
                        if (bufferString.Length > 0)
                        {
                            string[] part = bufferString.Split(';');// роздільние
                            if (part.Length == 3)
                            {
                                Array.Resize(ref events, events.Length + 1);
                                events[events.Length - 1] = new EventCalendar(part[0], part[1], part[2]);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        public void Save()
        {
            try
            {
                using (StreamWriter writer = new StreamWriter("persist.txt", false, Encoding.UTF8))
                {
                    foreach (EventCalendar currentEvent in events)
                    {
                        writer.WriteLine(currentEvent.ToString());
                    }
                    writer.Flush();
                }
            }
            catch (Exception e)
            {
            }
        }

        public bool AddEvent(EventCalendar currentEvent)
        {
            if (currentEvent.IsCreated())
            {
                Array.Resize(ref events, events.Length + 1);
                events[events.Length - 1] = currentEvent;
                return true;
            }
            return false;
        }

        public string GetEventByDate(DateTime currentDate)
        {
            string[] details = new string[0];
            foreach (EventCalendar currentEvent in events)
            {
                if (currentEvent.IsCurrectDate(currentDate))
                {
                    Array.Resize(ref details, details.Length + 1);
                    details[details.Length - 1] = currentEvent.Info();
                }
            }
            return String.Join("\n", details);
        }
        // підрахунок навантаження
        public int CountStatistics(DateTime currentDate, out int freeDays)
        {
            freeDays = 0;
            int busyDays = 0;
            DateTime processingDate = currentDate.AddDays(1 - currentDate.Day);
            
            while (processingDate.Month == currentDate.Month)
            {
                if (GetEventByDate(processingDate).Length > 0)
                {
                    busyDays++;
                }
                else freeDays++;
                processingDate = processingDate.AddDays(1);
            }
            return busyDays;
        }
    }
    // створення події
    public class EventCalendar 
    {
        DateTime Time { get; set; }
        string Event { get; set; }

        public EventCalendar(string data, string time, string eventString) 
        {
            DateTime bufferTime;
            bool isCreate = DateTime.TryParseExact((data + time), "dd.MM.yyHH:mm", new CultureInfo("en-US"), DateTimeStyles.None, out bufferTime);
            if (isCreate)
            {
                Time = bufferTime;
                Event = eventString;
            }
        }

        public string Info()
        {
            return Time.ToString("HH:mm - ") + Event;
        }

        public bool IsCurrectDate(DateTime currentDate)
        {
            return Time.Year == currentDate.Year && Time.DayOfYear == currentDate.DayOfYear;
        }

        public bool IsCreated()
        {
            return Time != null && Event != null;
        }

        public override string ToString() 
        {
            return Time.ToString("dd.MM.yy;HH:mm;") + Event;
        }
    }

}